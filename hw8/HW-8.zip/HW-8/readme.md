# Mart441
# Homework Assignment 8
## Allen Harguess

The viewable version of this assignment is at [HW-8](https://allenharguess701.github.io/Mart441/HW-8/)

### Work Flow
I was really pressed for time and so i did not merge this assignment with the overall ongoing website. I had lots of problems with both the github live server rendering the code and my live server. The code would just stop for no reason.

Ultimately i did get it done; although it took far longer than I hoped it would and took a lot of research. I looked over many fellow classmate's code just to see their take on the assignment.
i am hosting the code on both my github account assessed via the link above and on my personal server at http://www.harguess.com/hw8/
